# MediReminder – Android app

A reminder tool only. It gives no medical advice and never replaces your doctor or pharmacist.

## Build the installable app (APK)
Needs: Node.js 20+ and Android Studio (includes the Android SDK).

    npm install
    npx cap add android
    npm run icons
    npx cap sync android
    npx cap open android

In Android Studio wait for Gradle to finish, plug in your phone (USB debugging on) and press Run,
or use Build > Build Bundle(s) / APK(s) > Build APK(s) and install the APK.

On first launch allow **Notifications**. On Android 12+ also allow **Alarms & reminders**
(Settings > Apps > MediReminder) so reminders arrive on time.

## How alerts work in the app
The app schedules a phone alarm-style notification for every dose in the next 7 days, so reminders
appear on the lock screen and over other apps even when MediReminder is closed. Open the app at
least once a week to schedule the next days. Marking Taken or Skip, snoozing, pausing, editing or
deleting a medicine updates the scheduled notifications automatically.

## Run as an installable web app instead
Upload the `www` folder to any HTTPS host and use "Add to Home Screen". Alerts then work only while
the app is open (web limits).

## Notes
- Data is stored on the phone only. No account, no sync between devices.
- Edit `www/index.html` to change the app, then run `npx cap sync android`.
