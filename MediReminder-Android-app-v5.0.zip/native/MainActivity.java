package com.medireminder.app;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;
public class MainActivity extends BridgeActivity {
  @Override public void onCreate(Bundle s){ registerPlugin(MedAlarmPlugin.class); super.onCreate(s); flags(getIntent()); }
  @Override protected void onNewIntent(Intent i){ super.onNewIntent(i); flags(i); }
  private void flags(Intent i){
    if(i==null||!i.getBooleanExtra("alarm",false)) return;
    if(Build.VERSION.SDK_INT>=27){ setShowWhenLocked(true); setTurnScreenOn(true); }
    else getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED|WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
  }
}
