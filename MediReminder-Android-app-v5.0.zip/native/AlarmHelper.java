package com.medireminder.app;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import org.json.JSONArray;
import org.json.JSONObject;
class AlarmHelper {
  static void set(Context c,int id,long at,String name,String dose){
    Intent i=new Intent(c,AlarmReceiver.class).putExtra("name",name).putExtra("dose",dose);
    PendingIntent pi=PendingIntent.getBroadcast(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    PendingIntent show=PendingIntent.getActivity(c,0,new Intent(c,MainActivity.class),PendingIntent.FLAG_IMMUTABLE);
    ((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).setAlarmClock(new AlarmManager.AlarmClockInfo(at,show),pi);
  }
  static void cancelAll(Context c){
    try{
      AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
      JSONArray a=new JSONArray(c.getSharedPreferences("medalarms",0).getString("a","[]"));
      for(int k=0;k<a.length();k++){
        PendingIntent pi=PendingIntent.getBroadcast(c,a.getJSONObject(k).getInt("id"),new Intent(c,AlarmReceiver.class),PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);
        if(pi!=null){ am.cancel(pi); pi.cancel(); }
      }
    }catch(Exception e){}
  }
  static void apply(Context c,String json){
    try{
      JSONArray a=new JSONArray(json); long now=System.currentTimeMillis();
      for(int k=0;k<a.length();k++){ JSONObject o=a.getJSONObject(k); long at=o.getLong("at");
        if(at>now) set(c,o.getInt("id"),at,o.optString("name"),o.optString("dose")); }
    }catch(Exception e){}
  }
  static void schedule(Context c,String json){ cancelAll(c); c.getSharedPreferences("medalarms",0).edit().putString("a",json).apply(); apply(c,json); }
}
