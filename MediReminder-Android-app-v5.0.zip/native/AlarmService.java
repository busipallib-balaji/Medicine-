package com.medireminder.app;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Vibrator;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import androidx.core.app.NotificationCompat;
import java.util.Locale;
public class AlarmService extends Service implements TextToSpeech.OnInitListener {
  private MediaPlayer mp; private TextToSpeech tts; private boolean ready; private String line="Time to take your medicine",nm0="your medicine"; private final java.util.ArrayList<String[]> q=new java.util.ArrayList<>();
  private final Handler h=new Handler(Looper.getMainLooper()); private Vibrator vib; private PowerManager.WakeLock wl;
  private final Runnable loop=new Runnable(){ public void run(){ speak(); h.postDelayed(this,20000); } };
  @Override public IBinder onBind(Intent i){ return null; }
  @Override public int onStartCommand(Intent in,int flags,int startId){
    cleanup();
    String name=in!=null?in.getStringExtra("name"):null, dose=in!=null?in.getStringExtra("dose"):null;
    if(name==null) name="your medicine";
    line="Time to take "+name; nm0=name;
    NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
    if(Build.VERSION.SDK_INT>=26){ NotificationChannel ch=new NotificationChannel("medalarm","Medicine alarms",NotificationManager.IMPORTANCE_HIGH);
      ch.setSound(null,null); ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC); nm.createNotificationChannel(ch); }
    Intent open=new Intent(this,MainActivity.class).putExtra("alarm",true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
    PendingIntent pi=PendingIntent.getActivity(this,1,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    Notification n=new NotificationCompat.Builder(this,"medalarm").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
      .setContentTitle("\uD83D\uDC8A Time to take "+name)
      .setContentText("It's time for your scheduled medicine: "+name+(dose!=null&&!dose.isEmpty()?", "+dose:"")+".")
      .setPriority(NotificationCompat.PRIORITY_MAX).setCategory(NotificationCompat.CATEGORY_ALARM).setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
      .setOngoing(true).setFullScreenIntent(pi,true).setContentIntent(pi).build();
    if(Build.VERSION.SDK_INT>=29) startForeground(1,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK); else startForeground(1,n);
    try{ wl=((PowerManager)getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.FULL_WAKE_LOCK|PowerManager.ACQUIRE_CAUSES_WAKEUP,"MediReminder:alarm"); wl.acquire(180000); }catch(Exception e){}
    try{ AudioManager am=(AudioManager)getSystemService(AUDIO_SERVICE); am.setStreamVolume(AudioManager.STREAM_ALARM,am.getStreamMaxVolume(AudioManager.STREAM_ALARM),0); }catch(Exception e){}
    try{ mp=new MediaPlayer(); mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
      mp.setDataSource(this,RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)); mp.setLooping(true); mp.setVolume(0.4f,0.4f); mp.prepare(); mp.start(); }catch(Exception e){}
    try{ vib=(Vibrator)getSystemService(VIBRATOR_SERVICE); if(vib!=null) vib.vibrate(new long[]{0,600,400},0); }catch(Exception e){}
    if(Settings.canDrawOverlays(this)){ try{ startActivity(open); }catch(Exception e){} }
    tts=new TextToSpeech(this,this);
    h.postDelayed(new Runnable(){ public void run(){ stopSelf(); } },180000);
    return START_NOT_STICKY;
  }
  @Override public void onInit(int s){
    if(s!=TextToSpeech.SUCCESS) return;
    ready=true; tts.setOnUtteranceProgressListener(new UtteranceProgressListener(){ public void onStart(String id){} public void onDone(String id){ h.post(new Runnable(){ public void run(){ next(); } }); } public void onError(String id){ h.post(new Runnable(){ public void run(){ next(); } }); } });
    tts.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
    h.post(loop);
  }
  private void speak(){
    if(!ready) return;
    String l=getSharedPreferences("medalarms",0).getString("lang","en");
    String[] en={"en",line}, hi={"hi",nm0+" दवा लेने का समय हो गया है"}, te={"te",nm0+" మందు తీసుకునే సమయం అయింది"};
    q.clear();
    if(l.equals("all")){ q.add(en); q.add(hi); q.add(te); }
    else { String[] p=l.equals("hi")?hi:l.equals("te")?te:en; q.add(p); q.add(p); q.add(p); }
    next();
  }
  private void next(){
    if(!ready||q.isEmpty()) return;
    String[] p=q.remove(0); String text=p[1];
    int r=tts.setLanguage(Locale.forLanguageTag(p[0]+"-IN"));
    if(r==TextToSpeech.LANG_MISSING_DATA||r==TextToSpeech.LANG_NOT_SUPPORTED){ tts.setLanguage(Locale.ENGLISH); text=line; }
    Bundle b=new Bundle(); b.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM,AudioManager.STREAM_ALARM); b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME,1f);
    tts.speak(text,TextToSpeech.QUEUE_FLUSH,b,"u"+System.nanoTime());
  }
  private void cleanup(){
    h.removeCallbacksAndMessages(null); ready=false;
    try{ if(mp!=null){ mp.stop(); mp.release(); } }catch(Exception e){} mp=null;
    try{ if(tts!=null){ tts.stop(); tts.shutdown(); } }catch(Exception e){} tts=null;
    try{ if(vib!=null) vib.cancel(); }catch(Exception e){}
    try{ if(wl!=null&&wl.isHeld()) wl.release(); }catch(Exception e){}
  }
  @Override public void onDestroy(){ cleanup(); stopForeground(true); super.onDestroy(); }
}
