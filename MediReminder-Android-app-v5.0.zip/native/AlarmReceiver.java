package com.medireminder.app;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.content.ContextCompat;
public class AlarmReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context c,Intent i){ ContextCompat.startForegroundService(c,new Intent(c,AlarmService.class).putExtras(i)); }
}
