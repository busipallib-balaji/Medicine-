package com.medireminder.app;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import com.getcapacitor.JSArray;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
@CapacitorPlugin(name="MedAlarm")
public class MedAlarmPlugin extends Plugin {
  private void go(Intent i){ i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); getContext().startActivity(i); }
  private Uri pkg(){ return Uri.parse("package:"+getContext().getPackageName()); }
  @PluginMethod public void schedule(PluginCall c){
    try{ getContext().getSharedPreferences("medalarms",0).edit().putString("lang",c.getString("lang","en")).apply(); JSArray a=c.getArray("alarms"); AlarmHelper.schedule(getContext(),a==null?"[]":a.toString()); c.resolve(); }catch(Exception e){ c.reject(String.valueOf(e.getMessage())); } }
  @PluginMethod public void stop(PluginCall c){ getContext().stopService(new Intent(getContext(),AlarmService.class)); c.resolve(); }
  @PluginMethod public void test(PluginCall c){ AlarmHelper.set(getContext(),999999,System.currentTimeMillis()+10000,"Sample medicine","1 tablet"); c.resolve(); }
  @PluginMethod public void openOverlay(PluginCall c){ go(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,pkg())); c.resolve(); }
  @PluginMethod public void openFullScreen(PluginCall c){
    Intent i=Build.VERSION.SDK_INT>=34?new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,pkg())
      :new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getContext().getPackageName());
    go(i); c.resolve(); }
  @PluginMethod public void openBattery(PluginCall c){ try{ go(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,pkg())); }catch(Exception e){ go(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); } c.resolve(); }
}
