package com.medireminder.app;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class BootReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context c,Intent i){ AlarmHelper.apply(c,c.getSharedPreferences("medalarms",0).getString("a","[]")); }
}
