# MediReminder 5.0 – Android app

A reminder tool only. It gives no medical advice and never replaces your doctor or pharmacist.

## Easiest: build the APK in the cloud (no Android Studio)
1. Create a free GitHub account and a new empty repository.
2. Upload everything in this folder to it (including the hidden `.github` folder).
3. Open the repository's **Actions** tab, choose **Build Android APK**, press **Run workflow**.
4. After about 5 minutes open the finished run and download **MediReminder-apk** (a zip holding `app-debug.apk`).
5. Copy the APK to your phone, tap it, and allow "Install unknown apps" when asked.
6. Open MediReminder and allow **Notifications** and, on Android 12 or newer, **Alarms & reminders**.

## Or build it on your computer
Needs: Node.js 20+ and Android Studio (includes the Android SDK).

    npm install
    npx cap add android
    npm run icons
    npx cap sync android
    npx cap open android

In Android Studio wait for Gradle to finish, plug in your phone (USB debugging on) and press Run,
or use Build > Build Bundle(s) / APK(s) > Build APK(s) and install the APK.

On first launch allow **Notifications**. On Android 12+ also allow **Alarms & reminders**
(Settings > Apps > MediReminder) so reminders arrive on time.

## How alerts work in the app
The app schedules a phone alarm-style notification for every dose in the next 7 days, so reminders
appear on the lock screen and over other apps even when MediReminder is closed. Open the app at
least once a week to schedule the next days. Marking Taken or Skip, snoozing, pausing, editing or
deleting a medicine updates the scheduled notifications automatically.

## Run as an installable web app instead
Upload the `www` folder to any HTTPS host and use "Add to Home Screen". Alerts then work only while
the app is open (web limits).


## Full-screen alarm and loud voice (Android)
The app sets a real phone alarm for every dose in the next 7 days. When one is due, even with MediReminder closed, it:
- rings the alarm sound at full alarm volume and says "Time to take [medicine name]" loudly in English, Telugu, Hindi or all three (your choice in Settings → Voice language), repeating every 20 seconds. If a phone has no voice for a language, it speaks English instead (install the voice in phone Settings → Text-to-speech);
- vibrates and lights the screen;
- opens MediReminder full screen over the lock screen, or over any app you are using, showing Taken, Snooze and Skip.

The alarm stops when you press Taken, Snooze or Skip (or after 3 minutes).

On first launch a setup box asks you to allow three things (also under Settings > Full-screen alert setup):
1. **Display over other apps** (lets it pop up over any app you are using).
2. **Full-screen notifications** (lets it open over the lock screen on Android 14+).
3. **Run in background** (allow "No restrictions" for battery, so the phone never delays or kills alarms).
Then press **Test alarm** and switch to another app to see it.

The native code is in the `native` folder and `scripts/patch-android.py` adds it to the Android project during the build.

## Notes
- Data is stored on the phone only. No account, no sync between devices.
- Edit `www/index.html` to change the app, then run `npx cap sync android`.
