import os,shutil,sys
pkg='android/app/src/main/java/com/medireminder/app'
man='android/app/src/main/AndroidManifest.xml'
os.makedirs(pkg,exist_ok=True)
for f in os.listdir('native'):shutil.copy('native/'+f,pkg+'/'+f)
m=open(man).read()
perms=['POST_NOTIFICATIONS','SCHEDULE_EXACT_ALARM','USE_FULL_SCREEN_INTENT','FOREGROUND_SERVICE','FOREGROUND_SERVICE_MEDIA_PLAYBACK','WAKE_LOCK','VIBRATE','RECEIVE_BOOT_COMPLETED','SYSTEM_ALERT_WINDOW','REQUEST_IGNORE_BATTERY_OPTIMIZATIONS']
add=''.join('    <uses-permission android:name="android.permission.%s"/>\n'%p for p in perms if 'android.permission.%s"'%p not in m)
comp='''        <receiver android:name=".AlarmReceiver" android:exported="false"/>
        <receiver android:name=".BootReceiver" android:exported="true"><intent-filter><action android:name="android.intent.action.BOOT_COMPLETED"/></intent-filter></receiver>
        <service android:name=".AlarmService" android:exported="false" android:foregroundServiceType="mediaPlayback"/>
    '''
if '.AlarmService' not in m:
    assert '<application' in m and '</application>' in m
    m=m.replace('<application',add+'    <application',1).replace('</application>',comp+'</application>',1)
open(man,'w').write(m);print('patched',man)

import re
g='android/app/build.gradle'
if os.path.exists(g):
    t=open(g).read();t=re.sub(r'versionCode \d+','versionCode 5',t);t=re.sub(r'versionName "[^"]*"','versionName "5.0"',t);open(g,'w').write(t);print('version 5.0 set')
